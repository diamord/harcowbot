let admin = [
    '854196724939096085', // Sophia Ku
    '943832407247822859', // 成就
    '1111291968031563796' // 小帳
]

module.exports = admin